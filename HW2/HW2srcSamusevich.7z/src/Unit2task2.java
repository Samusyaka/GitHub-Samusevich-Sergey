public class Unit2task2 {
    public static void main (String[] args) {
        int a=1;
        int t;
        for (t=3; t<=24; t=t+3) {
            a = a * 2;
            System.out.println("По прошествии " + t + " часов амеба размножится до " + a+" особей");
        }

        }
    }

