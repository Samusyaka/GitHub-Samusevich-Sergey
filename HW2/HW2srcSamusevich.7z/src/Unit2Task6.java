public class Unit2Task6 {
    public static void main(String[] args) {
        int a = 2;
        System.out.println("Вывод четных чисел от 2 до 100 включительно");
        while (a <= 100) {
            System.out.print(a + " ");
            a=a+2;
        }
    }
}